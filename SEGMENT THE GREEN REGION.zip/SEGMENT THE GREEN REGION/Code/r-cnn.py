import cv2
import numpy as np
from sklearn.neighbors import KNeighborsClassifier

# Load the image
image = cv2.imread(r"D:\SEGMENT THE GREEN REGION\0_0_0 (1).png")

# Check if the image was loaded successfully
if image is None:
    print("Error: Could not load image. Please check the file path.")
    exit()

# Convert the image to HSV color space
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Reshape the image for easier processing
pixels = hsv.reshape(-1, 3)

# Define training data for green and non-green pixels
green = np.array([[60, 100, 100], [60, 255, 255]])  # HSV range for green

# Create labels for the training data
labels = np.zeros(len(pixels))

# Mark pixels within the green range as 1, others as 0
labels[(pixels[:, 0] >= green[0, 0]) & (pixels[:, 0] <= green[1, 0]) &
       (pixels[:, 1] >= green[0, 1]) & (pixels[:, 1] <= green[1, 1]) &
       (pixels[:, 2] >= green[0, 2]) & (pixels[:, 2] <= green[1, 2])] = 1

# Train the KNN classifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(pixels, labels)

# Predict on the entire image
predictions = knn.predict(pixels)

# Reshape the predictions back to the image shape
segmented = predictions.reshape(hsv.shape[:2])

# Convert the segmented image to binary (0 and 255)
segmented = (segmented * 255).astype(np.uint8)

# Optionally, you can apply a mask on the original image
mask = cv2.bitwise_and(image, image, mask=segmented)

# Save the results instead of displaying them
cv2.imwrite(r'D:\SEGMENT THE GREEN REGION\original_image.png', image)
cv2.imwrite(r'D:\SEGMENT THE GREEN REGION\segmented_green_region.png', mask)

print("Images saved successfully.")
